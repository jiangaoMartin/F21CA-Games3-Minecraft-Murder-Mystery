


   名称: Emoji+
   作者: 零雾〇五 Fogg05

● 作品基于 Fluent Emoji
https://github.com/microsoft/fluentui-emoji

● 作品发布
https://github.com/Fogg05/Emoji-Plus



   Title: Emoji+
   Author: 零雾〇五 Fogg05

● This pack is based on Fluent Emoji
https://github.com/microsoft/fluentui-emoji

● Github of this pack
https://github.com/Fogg05/Emoji-Plus



