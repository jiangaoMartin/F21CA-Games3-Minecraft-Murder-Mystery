


   名称: MCsans+
   作者: 零雾〇五 Fogg05

● 作品基于 NotoSans
https://github.com/notofonts/noto-cjk

● 作品发布
https://github.com/Fogg05/mcsans-plus



   Title: MCsans+
   Author: 零雾〇五 Fogg05

● This pack is based on NotoSans
https://github.com/notofonts/noto-cjk

● Github of this pack
https://github.com/Fogg05/mcsans-plus



